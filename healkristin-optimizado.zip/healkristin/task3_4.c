/*  Ficheiro task3_4.c:
    Verifica se tem a informação necessária e se é válidapara processar as tarefas 3 e 4;
    Função que calcula a distância entre duas cidades;
    Função que encontra o cluster de uma cidade;
    Função que encontra a cidade mais próxima de uma cidade de referência (Task3);
    Função que encontra a cidade mais próxima de um cluster de referência (Task4).
*/

#include <float.h>
#include "Task3Task4.h"

static int cluster_da_cidade(int cidade, const Rede *rede)
{
    if (rede == NULL ||
        rede->cluster_of == NULL ||
        cidade < 1 ||
        cidade > rede->C) {
        return -1;
    }

    return rede->cluster_of[cidade];
}

static double distancia2(int a, int b,
                         const Posicao *cidades)
{
    double dx = (double)cidades[a].x - cidades[b].x;
    double dy = (double)cidades[a].y - cidades[b].y;

    return dx * dx + dy * dy;
}

int Task3(int referencia, const Rede *rede,
          const Posicao *cidades)
{
    if (rede == NULL || cidades == NULL ||
        referencia < 1 || referencia > rede->C ||
        rede->num_clusters <= 1)
        return -2;

    int kref = cluster_da_cidade(referencia, rede);

    if (kref < 0)
        return -2;

    int melhor = -1;
    double melhor_d2 = DBL_MAX;

    for (int cidade = 1; cidade <= rede->C; cidade++) {
        if (cluster_da_cidade(cidade, rede) == kref)
            continue;

        double d2 = distancia2(referencia, cidade, cidades);

        if (d2 < melhor_d2) {
            melhor_d2 = d2;
            melhor = cidade;
        }
    }

    return melhor < 0 ? -2 : melhor;
}

int Task4(int referencia, const Rede *rede,
          const Posicao *cidades)
{
    if (rede == NULL || cidades == NULL ||
        referencia < 1 || referencia > rede->C ||
        rede->num_clusters <= 1)
        return -2;

    int kref = cluster_da_cidade(referencia, rede);

    if (kref < 0)
        return -2;

    int melhor = -1;
    double melhor_d2 = DBL_MAX;

    for (int externa = 1; externa <= rede->C; externa++) {
        if (rede->cluster_of[externa] == kref)
            continue;

        double minima = DBL_MAX;

        for (int j = 0;
             j < rede->cluster_sizes[kref]; j++) {
            int membro = rede->clusters[kref][j];

            double d2 = distancia2(membro, externa, cidades);

            if (d2 < minima)
                minima = d2;
        }

        if (minima < melhor_d2) {
            melhor_d2 = minima;
            melhor = externa;
        }
    }

    return melhor < 0 ? -2 : melhor;
}