#include <stdio.h>
#include <stdlib.h>
#include <float.h>
#include <math.h>

#include "task5.h"



// Estrutura que guarda a menor distância entre duas cidades para ser usada na Task 5
typedef struct {
    int cidade1;
    int cidade2;
    double distancia2;
} LigacaoMinima;

/* Ordena as ligações pelo ID da primeira cidade
   e depois pelo ID da segunda cidade,
   retorna -1 se a ligação a dever aparecer antes de b
   e retorna 1 caso contrário
   e 0 se forem iguais */
static int comparar_ligacoes(const void *p1, const void *p2)
{
    const LigacaoMST *a = p1;
    const LigacaoMST *b = p2;

    if (a->cidade1 < b->cidade1)
        return -1;

    if (a->cidade1 > b->cidade1)
        return 1;

    if (a->cidade2 < b->cidade2)
        return -1;

    if (a->cidade2 > b->cidade2)
        return 1;

    return 0;
}

// Função que encontra a ligação mínima entre dois clusters
static int encontrar_ligacao_minima(
    const Rede *rede,
    const Posicao *cidades,
    int cluster_a,
    int cluster_b,
    LigacaoMinima *resultado)
{
    double menor2 = DBL_MAX;

    int melhor_a = -1;
    int melhor_b = -1;

    int tamanho_a = rede->cluster_sizes[cluster_a];
    int tamanho_b = rede->cluster_sizes[cluster_b];

    // for que percorre todas as cidades de um cluster A
    for (int i = 0; i < tamanho_a; i++) {

        int a = rede->clusters[cluster_a][i];
        
        //for que percorre todas as cidades de um cluster B
        for (int j = 0; j < tamanho_b; j++) {

            int b = rede->clusters[cluster_b][j];

            double dx = (double)cidades[a].x -
                        (double)cidades[b].x;

            double dy = (double)cidades[a].y -
                        (double)cidades[b].y;

            double distancia2 = dx * dx + dy * dy;
            
            //garantimos que a cidade com o menor ID é sempre a primeira na ligação
            int cidade_menor = (a < b) ? a : b;
            int cidade_maior = (a < b) ? b : a;

            int melhor_menor =
                (melhor_a < melhor_b) ? melhor_a : melhor_b;

            int melhor_maior =
                (melhor_a < melhor_b) ? melhor_b : melhor_a;

            if (distancia2 < menor2 ||
                (distancia2 == menor2 &&
                 (melhor_a == -1 ||
                  cidade_menor < melhor_menor ||
                  (cidade_menor == melhor_menor &&
                   cidade_maior < melhor_maior)))) {

                menor2 = distancia2;
                melhor_a = cidade_menor;
                melhor_b = cidade_maior;
            }
        }
    }

    if (melhor_a == -1)
        return 0;

    resultado->cidade1 = melhor_a;
    resultado->cidade2 = melhor_b;
    resultado->distancia2 = menor2;

    return 1;
}




int construir_arvore_prim(const Rede *rede,
                          const Posicao *cidades,
                          ArvoreMST *arvore)
{
    int *visitado;
    double *melhor2;
    int *pai;
    int *cidade_pai;
    int *cidade_filho;

    if (rede == NULL || cidades == NULL || arvore == NULL)
        return 0;

    int k = rede->num_clusters;

    if (k <= 0)
        return 0;

    /* A função deve receber uma árvore vazia,
       inicialmente declarada com ArvoreMST arvore = {0} */
    arvore->num_clusters = k;
    arvore->num_ligacoes = 0;
    arvore->ligacoes = NULL;
    arvore->custo_total = 0.0;

    /* Se só existe um cluster, não há cabo adicional */
    if (k == 1)
        return 1;

    /* Reservar espaço para K-1 ligações */
    arvore->ligacoes =
        malloc((size_t)(k - 1) * sizeof(LigacaoMST));

    visitado = NULL;
    melhor2 = NULL;
    pai = NULL;
    cidade_pai = NULL;
    cidade_filho = NULL;

    visitado = calloc((size_t)k, sizeof(int));
    melhor2 = malloc((size_t)k * sizeof(double));
    pai = malloc((size_t)k * sizeof(int));
    cidade_pai = malloc((size_t)k * sizeof(int));
    cidade_filho = malloc((size_t)k * sizeof(int));

    if (arvore->ligacoes == NULL ||
        visitado == NULL ||
        melhor2 == NULL ||
        pai == NULL ||
        cidade_pai == NULL ||
        cidade_filho == NULL)
        goto erro;

    /* Inicializar os vetores */
    for (int i = 0; i < k; i++) {
        melhor2[i] = DBL_MAX;
        pai[i] = -1;
        cidade_pai[i] = -1;
        cidade_filho[i] = -1;
    }

    /* Escolher o cluster 0 como ponto de partida */
    visitado[0] = 1;

    /* Calcular as melhores ligações iniciais
       entre o cluster 0 e os restantes clusters */
     
    for (int v = 1; v < k; v++) {

        LigacaoMinima candidata;

        if (!encontrar_ligacao_minima(
                rede, cidades, 0, v, &candidata))
            goto erro;

        melhor2[v] = candidata.distancia2;
        pai[v] = 0;

        cidade_pai[v] = candidata.cidade1;
        cidade_filho[v] = candidata.cidade2;
    }

    /* Repetir até adicionar K-1 ligações */
    for (int passo = 0; passo < k - 1; passo++) {

        int escolhido = -1;
        double menor = DBL_MAX;

        /* 1. Escolher o cluster ainda não visitado
              cuja ligação à árvore é mais barata */
        for (int v = 0; v < k; v++) {

            if (!visitado[v] && melhor2[v] < menor) {
                menor = melhor2[v];
                escolhido = v;
            }
        }

        if (escolhido == -1 || pai[escolhido] == -1)
            goto erro;

        /* 2. Guardar a ligação escolhida */
        LigacaoMST *nova =
            &arvore->ligacoes[arvore->num_ligacoes];

        nova->cluster_origem = pai[escolhido];
        nova->cluster_destino = escolhido;

        nova->cidade1 = cidade_pai[escolhido];
        nova->cidade2 = cidade_filho[escolhido];

        nova->distancia = sqrt(menor);

        arvore->custo_total += nova->distancia;
        arvore->num_ligacoes++;

        /* O cluster passa a fazer parte da árvore */
        visitado[escolhido] = 1;

        /* 3. Atualizar as melhores ligações para os clusters que ainda não foram visitados */
        for (int u = 0; u < k; u++) {

            if (!visitado[u]) {

                LigacaoMinima candidata;

                if (!encontrar_ligacao_minima(
                        rede, cidades, escolhido, u, &candidata))
                    goto erro;

                if (candidata.distancia2 < melhor2[u]) {

                    melhor2[u] = candidata.distancia2;

                    pai[u] = escolhido;

                    cidade_pai[u] = candidata.cidade1;
                    cidade_filho[u] = candidata.cidade2;
                }
            }
        }
    }

    // Ordenar as ligações
    if (arvore->num_ligacoes > 1) {

        qsort(arvore->ligacoes,
              (size_t)arvore->num_ligacoes,
              sizeof(LigacaoMST),
              comparar_ligacoes);
    }

    free(visitado);
    free(melhor2);
    free(pai);
    free(cidade_pai);
    free(cidade_filho);

    return 1;


erro: /*usamos goto para evitar duplicação de código de libertação de memória
        mesmo que os professores não gostem muito, neste caso parece melhor usar*/

    free(visitado);
    free(melhor2);
    free(pai);
    free(cidade_pai);
    free(cidade_filho);

    libertar_arvore_mst(arvore);

    return 0;
}

void escrever_task5(FILE *saida, const ArvoreMST *arvore)
{
    fprintf(saida, "Task5 %.2f\n", arvore->custo_total);

    for (int i = 0; i < arvore->num_ligacoes; i++) {

        fprintf(saida, "%d %d %.2f\n",
                arvore->ligacoes[i].cidade1,
                arvore->ligacoes[i].cidade2,
                arvore->ligacoes[i].distancia);
    }
    fputc('\n', saida);
}

void libertar_arvore_mst(ArvoreMST *arvore)
{
    if (arvore == NULL)
        return;

    free(arvore->ligacoes);

    arvore->ligacoes = NULL;
    arvore->num_clusters = 0;
    arvore->num_ligacoes = 0;
    arvore->custo_total = 0.0;
}