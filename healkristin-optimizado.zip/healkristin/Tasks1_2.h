#ifndef TASKS1_2_H
#define TASKS1_2_H

#include <stdio.h>

// Estrutura para armazenar a informação global dos clusters da rede
typedef struct {
    int C;                 // Número de cidades
    // possívelmente desnecessário int L;                 // Número de ligações
    int num_clusters;      // Número  de clusters
    int **clusters;        // IDs das cidades
    int *cluster_sizes;    // Tamanho de cada cluster
    int *cluster_of;       // Índice do cluster de cada cidade
} Rede;

Rede *carregar_e_processar_mapa(FILE *f_map);
void libertar_rede(Rede *rede);

#endif 