#ifndef TASK5_6_H
#define TASK5_6_H

#include "Tasks1_2.h"
#include "position.h"

/* Uma ligação de restauro escolhida pelo Prim. */
typedef struct {
    int cluster_origem;
    int cluster_destino;

    int cidade1;
    int cidade2;

    double distancia;
} LigacaoMST;

/* Resultado completo da Task 5. */
typedef struct {
    int num_clusters;
    int num_ligacoes;

    LigacaoMST *ligacoes;

    double custo_total;
} ArvoreMST;

int construir_arvore_prim(const Rede *rede,
                          const Posicao *cidades,
                          ArvoreMST *arvore);

void libertar_arvore_mst(ArvoreMST *arvore);

void escrever_task5(FILE *saida, const ArvoreMST *arvore);

#endif