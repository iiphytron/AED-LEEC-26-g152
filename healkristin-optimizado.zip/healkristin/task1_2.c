/*  Ficheiro task1_2.c:
    Guarda o valor C(número de cidades) e L(número de ligações) lidos na primeira linha do ficheiro .map;
    Aplica o algoritmo Quick-Find para unir cidades no mesmo cluster;
    Faz malloc dos clusters e das suas dimensões;
    Coloca as cidades nos clusters correspondentes;
    Liberta a memória alocada para a estrutura da rede;
    Processa as tarefas 1 e 2, escrevendo os resultados no ficheiro .results.
*/

#include <stdio.h>
#include <stdlib.h>
#include "Tasks1_2.h"



//Aplica o algoritmo Quick-Find para unir duas cidades (A e B) no mesmo cluster.
static void quick_find_union(int id[], int A, int B, int C) {
    int valorA = id[A];
    int valorB = id[B];

    if (valorA == valorB) return;

    for (int i = 1; i <= C; i++) {
        if (id[i] == valorA) {
            id[i] = valorB;
        }
    }
}

/* Lê o ficheiro .map e constrói a estrutura de clusters organizada */
Rede *carregar_e_processar_mapa(FILE *f_map) {
    /* Se o ficheiro estiver vazio, tiver mais do dois valores na primeira linha,
    C for menor ou igual a 0, ou L for negativo; retorna NULL */
    int C, L;

    if (f_map == NULL ||
        fscanf(f_map, "%d %d", &C, &L) != 2 ||
        C <= 0 || L < 0) {
        return NULL;
    }

    /* Aloca memória (em zeros para não termos valores aleatórios em C e L,
    tal como nas outras variáveis) do tamanho da estrutura Rede e dá return NULL se não houver rede armazenada */
    Rede *rede = (Rede *) calloc(1, sizeof(Rede));
    if (!rede) return NULL;
    // Inicializa os valores de C e L na estrutura Rede com ponteiros para uso posterior
    rede->C = C;
    // ver header rede->L = L;



    /* 1. Inicializar os vetores, reservando espaço na memória, de "id" e "usado" para o Quick-Find,
          sendo "id" para armazenar o ID do cluster de cada cidade e
          "usado" para marcar as cidades já processadas */
    int *id = (int *) malloc((C + 1) * sizeof(int));
    int *usado = (int *) calloc((C + 1), sizeof(int));

    // Inicialização do Quick-Find: cada cidade começa no seu próprio conjunto
    for (int i = 1; i <= C; i++) {
        id[i] = i;
    }

    // 2. Ler as L ligações físicas do ficheiro .map
    for (int i = 0; i < L; i++) {
        int A, B;
        if (fscanf(f_map, "%d %d", &A, &B) == 2) {
            if (A >= 1 && A <= C && B >= 1 && B <= C) {
                quick_find_union(id, A, B, C);
            }
        }
    }

    // 3. Alocar memória para os clusters
    rede->clusters = (int **) malloc(C * sizeof(int *));
    rede->cluster_sizes = (int *) calloc(C, sizeof(int));
    for (int i = 0; i < C; i++) {
        rede->clusters[i] = (int *) malloc(C * sizeof(int));
    }

    //adicionado para teste (não verificado)
    rede->cluster_of = malloc((C + 1) * sizeof(int));

    if (rede->cluster_of == NULL) {
    free(id);
    free(usado);
    free(rede);
    return NULL;
    }

    for (int i = 0; i <= C; i++) {
    rede->cluster_of[i] = -1;
    }
    // Fim do trecho adicionado para teste (não verificado)
    
    rede->num_clusters = 0;

    // Agrupar as cidades.
    while (1) {
        int primeiraCidade = -1;

        // Encontra a menor cidade ainda não processada
        for (int i = 1; i <= C; i++) {
            if (usado[i] == 0) {
                primeiraCidade = i;
                break;
            }
        }

        if (primeiraCidade == -1) break; // Todas as cidades processadas

        int valorCluster = id[primeiraCidade];
        int idx_cidade = 0;

        for (int j = 1; j <= C; j++) {
            if (usado[j] == 0 && id[j] == valorCluster) {
                //parte experimental para teste (não verificado)
                int k = rede->num_clusters;
                rede->clusters[k][idx_cidade++] = j;
                rede->cluster_of[j] = k;

                usado[j] = 1;
                // Fim da parte experimental para teste (não verificado)
            }
        }

        rede->cluster_sizes[rede->num_clusters] = idx_cidade;
        rede->num_clusters++;
    }

    free(id);
    free(usado);
    return rede;
}

/* Liberta a memória alocada para a estrutura da rede */
void libertar_rede(Rede *rede) {
    if (!rede) return;
    for (int i = 0; i < rede->C; i++) {
        free(rede->clusters[i]);
    }
    free(rede->clusters);
    free(rede->cluster_sizes);
    free(rede->cluster_of);
    free(rede);
}

